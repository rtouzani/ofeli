var classOFELI_1_1EC2D1T3 =
[
    [ "EC2D1T3", "classOFELI_1_1EC2D1T3.html#ab638033b9ad8530248bbbef11dfd38a6", null ],
    [ "EC2D1T3", "classOFELI_1_1EC2D1T3.html#adaea309cdd252646e9be99bb1948bf58", null ],
    [ "EC2D1T3", "classOFELI_1_1EC2D1T3.html#a6850571c352bcc70d85144a7e5d6a190", null ],
    [ "~EC2D1T3", "classOFELI_1_1EC2D1T3.html#adca0e5a01e47556f801da6f15297e599", null ],
    [ "build", "classOFELI_1_1EC2D1T3.html#a7740c7ab195c03ac140f1f75f633470f", null ],
    [ "Electric", "classOFELI_1_1EC2D1T3.html#ae084a5bbc907cd30e354786d52a2ed8c", null ],
    [ "IntegMF", "classOFELI_1_1EC2D1T3.html#a67ec028eed371bb07ca3bc2dcb40f902", null ],
    [ "IntegND", "classOFELI_1_1EC2D1T3.html#af2e22ffe435f7aeaaacad73747acf585", null ],
    [ "Joule", "classOFELI_1_1EC2D1T3.html#a2037770b94084f7dc2089fe3c9f799e6", null ],
    [ "Magnetic", "classOFELI_1_1EC2D1T3.html#ae96fba287155ef1ab77778cb006efcc3", null ],
    [ "setData", "classOFELI_1_1EC2D1T3.html#a29983d2bbe759ccbbf9f48d924fafd05", null ],
    [ "VacuumArea", "classOFELI_1_1EC2D1T3.html#ad72794a6ed20f261ab690830abb3ccee", null ]
];