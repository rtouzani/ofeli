var classOFELI_1_1NSP2DQ41 =
[
    [ "NSP2DQ41", "classOFELI_1_1NSP2DQ41.html#a96451a67be2c8d82f95db41bc77cead1", null ],
    [ "NSP2DQ41", "classOFELI_1_1NSP2DQ41.html#a84a5ed3affb0030e22f2efbfc1102962", null ],
    [ "~NSP2DQ41", "classOFELI_1_1NSP2DQ41.html#a12fe9b1ca3c86d5d27cb0280ceaa4a3a", null ],
    [ "build", "classOFELI_1_1NSP2DQ41.html#a7740c7ab195c03ac140f1f75f633470f", null ],
    [ "Periodic", "classOFELI_1_1NSP2DQ41.html#af669369716d638f14a268133981dbb17", null ],
    [ "runOneTimeStep", "classOFELI_1_1NSP2DQ41.html#a97ceb92f009f5eee1340388708fd5939", null ],
    [ "setInput", "classOFELI_1_1NSP2DQ41.html#affbdc0fae478891f2b9f63607004026f", null ],
    [ "setPenalty", "classOFELI_1_1NSP2DQ41.html#aef525ad3a42dedd8346b084b3e303272", null ]
];