var classOFELI_1_1Figure =
[
    [ "Figure", "classOFELI_1_1Figure.html#ae49c513c5bcadb29c0764c1746bfd924", null ],
    [ "Figure", "classOFELI_1_1Figure.html#ae0b3ecf250250edd504dd29bf970a7bc", null ],
    [ "~Figure", "classOFELI_1_1Figure.html#ac2356b66e5c02f39b568f4c8a7651e36", null ],
    [ "dLine", "classOFELI_1_1Figure.html#a740ca39646f05723f2f96ab62a232b36", null ],
    [ "getSignedDistance", "classOFELI_1_1Figure.html#a2252be7c4949c4a2bd3ee24a4fdfd722", null ],
    [ "getSignedDistance", "classOFELI_1_1Figure.html#a59bcb59a9fd6e717fa480630c7d3b57a", null ],
    [ "operator=", "classOFELI_1_1Figure.html#a42041bd53cf657f479fe30a8763f4116", null ],
    [ "setCode", "classOFELI_1_1Figure.html#a2520b3fc10894bb8fc4a96014dfb0d08", null ]
];