var classOFELI_1_1Laplace1DL2 =
[
    [ "Laplace1DL2", "classOFELI_1_1Laplace1DL2.html#a99491e895db140230776a3316c9e129e", null ],
    [ "Laplace1DL2", "classOFELI_1_1Laplace1DL2.html#ab413f599660a00bf7f20a48e61f466a9", null ],
    [ "Laplace1DL2", "classOFELI_1_1Laplace1DL2.html#a2812443a9ce5a762d4382268112acc97", null ],
    [ "~Laplace1DL2", "classOFELI_1_1Laplace1DL2.html#a5478ca9494fb3f8ae3eb3efc072aeb7f", null ],
    [ "BodyRHS", "classOFELI_1_1Laplace1DL2.html#aa6d7e87afcbeea4276573c9576d8d6ca", null ],
    [ "BoundaryRHS", "classOFELI_1_1Laplace1DL2.html#a9f47743e35b40517037f6c007312461c", null ],
    [ "buildEigen", "classOFELI_1_1Laplace1DL2.html#aa29ea1739165c677b1353892bfaff103", null ],
    [ "LHS", "classOFELI_1_1Laplace1DL2.html#a906da27903ef1eb8d13377b70044b2cd", null ],
    [ "setBC1D", "classOFELI_1_1Laplace1DL2.html#a9044d18b5ec1c4aea6a48181bcf5f35a", null ],
    [ "setNeumann1D", "classOFELI_1_1Laplace1DL2.html#a9a2ff293661184b5e8e89c94c37a0d2b", null ]
];