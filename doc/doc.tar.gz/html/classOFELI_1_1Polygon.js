var classOFELI_1_1Polygon =
[
    [ "Polygon", "classOFELI_1_1Polygon.html#ac5fdf39c745fba4ea13ef9776cdc14e1", null ],
    [ "dLine", "classOFELI_1_1Polygon.html#a740ca39646f05723f2f96ab62a232b36", null ],
    [ "getSignedDistance", "classOFELI_1_1Polygon.html#a2252be7c4949c4a2bd3ee24a4fdfd722", null ],
    [ "getSignedDistance", "classOFELI_1_1Polygon.html#a59bcb59a9fd6e717fa480630c7d3b57a", null ],
    [ "getSignedDistance", "classOFELI_1_1Polygon.html#a6c92f703c9cacfbfc0158713655d844a", null ],
    [ "operator+=", "classOFELI_1_1Polygon.html#aff4d46efc6540f17ee20c030b2170299", null ],
    [ "operator+=", "classOFELI_1_1Polygon.html#aa63003acd7d475aa683090323f421aeb", null ],
    [ "polygon", "classOFELI_1_1Polygon.html#a15bf0e9badc1110318080057a7f76fce", null ],
    [ "setVertices", "classOFELI_1_1Polygon.html#a608f8fc85e0db7062f76c4d568b67f8e", null ]
];