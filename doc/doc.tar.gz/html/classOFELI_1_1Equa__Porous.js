var classOFELI_1_1Equa__Porous =
[
    [ "Equa_Porous", "classOFELI_1_1Equa__Porous.html#a4828a4a25bb1d319095e492290d3a756", null ],
    [ "~Equa_Porous", "classOFELI_1_1Equa__Porous.html#ac34e8344a9adbe72eb497a7c9de0ccfe", null ],
    [ "BodyRHS", "classOFELI_1_1Equa__Porous.html#a4a93a6ae518606a36e7a099ac170483c", null ],
    [ "BoundaryRHS", "classOFELI_1_1Equa__Porous.html#a0c6ef2f4383b0dbf335c197f290f508f", null ],
    [ "build", "classOFELI_1_1Equa__Porous.html#a7740c7ab195c03ac140f1f75f633470f", null ],
    [ "build", "classOFELI_1_1Equa__Porous.html#a707e4f7e7fe3140fd7a6fefe4774f03d", null ],
    [ "build", "classOFELI_1_1Equa__Porous.html#a3d205a8b8188a1e0d1e07091b775bbe7", null ],
    [ "Mass", "classOFELI_1_1Equa__Porous.html#a4b5788aa0557f7b6698712490fe5dbfa", null ],
    [ "Mobility", "classOFELI_1_1Equa__Porous.html#acceb9ec981656f82b38c1a7552d73bfe", null ],
    [ "Mu", "classOFELI_1_1Equa__Porous.html#a361540d92ccffb977940130e35ffcd3a", null ],
    [ "run", "classOFELI_1_1Equa__Porous.html#a58e8be2db2660128e4e6456a9c981fb5", null ],
    [ "setMaterial", "classOFELI_1_1Equa__Porous.html#a381ccce0928fbad840a57b054e7eb9b0", null ]
];