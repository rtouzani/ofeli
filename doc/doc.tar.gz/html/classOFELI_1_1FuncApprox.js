var classOFELI_1_1FuncApprox =
[
    [ "FuncApprox", "group__OFELI.html#gaa7d0387fa742ec6a4e2a760ddb7e3c96", null ],
    [ "~FuncApprox", "group__OFELI.html#gade51dae9bafad478abfb51dc51d725ed", null ],
    [ "getLeastSquare", "group__OFELI.html#ga7e0f44528e64ceb4354b6cd37ece6e67", null ],
    [ "run", "group__OFELI.html#ga58e8be2db2660128e4e6456a9c981fb5", null ],
    [ "setBezier", "group__OFELI.html#gad4a1ba7522a5ae99754fdaebd036dfe0", null ],
    [ "setBezierSurface", "group__OFELI.html#ga132380063b1aba64f3c3499ef7dbb987", null ],
    [ "setBSpline", "group__OFELI.html#gaf57b39df590265a6ae74083caa0cc090", null ],
    [ "setBSplineSurface", "group__OFELI.html#gaba03264b03c63ce83975295ac716a17f", null ],
    [ "setLagrange", "group__OFELI.html#ga973019c85316cddc6cb3822bd0aaab9c", null ],
    [ "setLeastSquare", "group__OFELI.html#ga01c9e91de8d397ba9dbf69622edfd2b3", null ],
    [ "setLeastSquare", "group__OFELI.html#ga2e59eaea69646ad8caa59b989a16b1a8", null ],
    [ "setLeastSquare", "group__OFELI.html#gac96c5aabfb4bd1296dfe95e9b880b1b7", null ],
    [ "setLeastSquare", "group__OFELI.html#ga83df464ff0de59d7542360770442f45e", null ],
    [ "setNurbs", "group__OFELI.html#ga1768ad077affc82b1f36d2d757d50d74", null ],
    [ "setNurbsSurface", "group__OFELI.html#ga94cdbc4d399b18d23acda22e80360b9b", null ]
];