var classOFELI_1_1Iter =
[
    [ "Iter", "group__OFELI.html#ga52a964fddab510b9f151dc0e0fd611b8", null ],
    [ "Iter", "group__OFELI.html#ga84d8bca72783e4b905ec5f00831222c3", null ],
    [ "~Iter", "classOFELI_1_1Iter.html#a751679d9eef045b4d2ea9688e746b9b5", null ],
    [ "check", "group__OFELI.html#gacd18d8209c23c006d7a0ba574cda652b", null ],
    [ "check", "group__OFELI.html#gaec86278ba42d21024e3e9da1a57ee08d", null ],
    [ "setMaxIter", "classOFELI_1_1Iter.html#a9e6d15777f4c9d95999313bafae5e5e7", null ],
    [ "setTolerance", "classOFELI_1_1Iter.html#a4d0e665f8f92335ec10c4ccf9e9171b7", null ],
    [ "setVerbose", "classOFELI_1_1Iter.html#afc81729fb2aa1720f446f48f1c3977ff", null ]
];