var classOFELI_1_1Laplace1DL3 =
[
    [ "Laplace1DL3", "classOFELI_1_1Laplace1DL3.html#acb9177af80553f13bad2c704feb6f20f", null ],
    [ "Laplace1DL3", "classOFELI_1_1Laplace1DL3.html#aa3c3bc48521536029513c7851815dc42", null ],
    [ "Laplace1DL3", "classOFELI_1_1Laplace1DL3.html#a101f6995b133edc6a6a3f437a990ba3d", null ],
    [ "~Laplace1DL3", "classOFELI_1_1Laplace1DL3.html#a833e625949a2c7c502b3381f66d4093a", null ],
    [ "BodyRHS", "classOFELI_1_1Laplace1DL3.html#aa6d7e87afcbeea4276573c9576d8d6ca", null ],
    [ "BoundaryRHS", "classOFELI_1_1Laplace1DL3.html#a735f7f78ccee2864d719a9aba4bea313", null ],
    [ "LHS", "classOFELI_1_1Laplace1DL3.html#a906da27903ef1eb8d13377b70044b2cd", null ],
    [ "setNeumann1D", "classOFELI_1_1Laplace1DL3.html#a9a2ff293661184b5e8e89c94c37a0d2b", null ]
];