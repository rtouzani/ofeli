var classOFELI_1_1Integration =
[
    [ "Integration", "classOFELI_1_1Integration.html#a99fedbcd92c2d8eb0cab643e08a994ce", null ],
    [ "Integration", "classOFELI_1_1Integration.html#a4672d48296cbd574da470eb710122a7a", null ],
    [ "~Integration", "classOFELI_1_1Integration.html#a27fdc443e848f75da803e3d08a7d7f85", null ],
    [ "run", "classOFELI_1_1Integration.html#a4e221062ec88b6f591aa4501f4f7d9b5", null ],
    [ "setFunction", "classOFELI_1_1Integration.html#a85b46015bfb0e017ac6446556e107164", null ],
    [ "setQuadrilateral", "classOFELI_1_1Integration.html#a4746c65eef73fb00087c25afa2b5de25", null ],
    [ "setScheme", "classOFELI_1_1Integration.html#ae8a3575e77ddd46da6778d8de975e53a", null ],
    [ "setTriangle", "classOFELI_1_1Integration.html#a3072aedb92fde50d8b1201bf52ce192c", null ]
];