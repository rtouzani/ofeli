var classOFELI_1_1Equa =
[
    [ "Equa", "classOFELI_1_1Equa.html#aae7f04361ea6cc96d59317348467afa6", null ],
    [ "~Equa", "classOFELI_1_1Equa.html#a678813c91567f705fb361533d9c7f2bc", null ],
    [ "getLinearSolver", "classOFELI_1_1Equa.html#a4988b63cdeb08773e2bffc3591ac3bdb", null ],
    [ "getMatrix", "classOFELI_1_1Equa.html#afc12eef96402127dfff92558262c07b8", null ],
    [ "getMesh", "classOFELI_1_1Equa.html#a33d260bca42fe66a8536f2eac63adc64", null ],
    [ "LinearSystemInfo", "classOFELI_1_1Equa.html#ad25e8a8874756b7211620a56e04666c7", null ],
    [ "setMatrixType", "classOFELI_1_1Equa.html#a28dc6e37b3582dfaf59b23135fb06682", null ],
    [ "setMesh", "classOFELI_1_1Equa.html#a82708ffcc31d4d630863187f3f137ee3", null ],
    [ "setSolver", "classOFELI_1_1Equa.html#aa76ba7a5ad0412484df8aeaa34df03a3", null ],
    [ "solveLinearSystem", "classOFELI_1_1Equa.html#abff1dbe8f0d9a00693a159e6af5b60d1", null ],
    [ "solveLinearSystem", "classOFELI_1_1Equa.html#a7e915d3489c2fb77bd571c219d48533d", null ]
];