var classOFELI_1_1PhaseChange =
[
    [ "~PhaseChange", "classOFELI_1_1PhaseChange.html#a0b2a4806e16b0513726e5297240d99a5", null ],
    [ "E2T", "classOFELI_1_1PhaseChange.html#a38c8f28f91e3ad3331afbcb8aa6aecd8", null ],
    [ "EnthalpyToTemperature", "classOFELI_1_1PhaseChange.html#ae4095a91402d2959d88e8bcfcd272acb", null ],
    [ "getMaterial", "classOFELI_1_1PhaseChange.html#a0731a43d34c132f05bf4358397583e61", null ],
    [ "setMaterial", "classOFELI_1_1PhaseChange.html#a15843fe28b77d456800ca1dc64e693d4", null ]
];