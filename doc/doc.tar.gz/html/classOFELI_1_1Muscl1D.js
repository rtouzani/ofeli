var classOFELI_1_1Muscl1D =
[
    [ "Muscl1D", "classOFELI_1_1Muscl1D.html#a9bb51f17b72e2472af8310fa00edb835", null ],
    [ "~Muscl1D", "classOFELI_1_1Muscl1D.html#af6551c27f005eea191c5566befc603fc", null ],
    [ "getMaximumLength", "classOFELI_1_1Muscl1D.html#ade9fd22c0f2af5472903a0f5592a78db", null ],
    [ "getMeanLength", "classOFELI_1_1Muscl1D.html#aaac2a2828bceb6a000f4590b06945ede", null ],
    [ "getMinimumLength", "classOFELI_1_1Muscl1D.html#ab02ef1c815ff075446f737759c29c639", null ],
    [ "getTauLim", "classOFELI_1_1Muscl1D.html#a4e154184d43a6537f3d17a48ae6ba901", null ],
    [ "print_mesh_stat", "classOFELI_1_1Muscl1D.html#ad88bdd37b0477b14ec0821c5741ee95e", null ]
];