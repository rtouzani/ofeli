var classOFELI_1_1DG =
[
    [ "DG", "classOFELI_1_1DG.html#aeb953cf746c1b45576cb767cefcbe81f", null ],
    [ "~DG", "classOFELI_1_1DG.html#a6bab5798fe4280f5dd2631cd81f2549f", null ],
    [ "setGraph", "classOFELI_1_1DG.html#ac48e824f9733572fae5f1b012bb69c44", null ]
];