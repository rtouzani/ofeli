var classOFELI_1_1Estimator =
[
    [ "EstimatorType", "classOFELI_1_1Estimator.html#a3d248e8029a03537eb6296f93345f51e", [
      [ "ESTIM_ZZ", "classOFELI_1_1Estimator.html#a3d248e8029a03537eb6296f93345f51ea7794313b487e60087acd23190b1ef61d", null ],
      [ "ESTIM_ND_JUMP", "classOFELI_1_1Estimator.html#a3d248e8029a03537eb6296f93345f51eaca80926339029dc37fa92e00a4341e99", null ]
    ] ],
    [ "Estimator", "classOFELI_1_1Estimator.html#abb232095ed221e3cc2b045ff79053b51", null ],
    [ "Estimator", "classOFELI_1_1Estimator.html#ac75af9393b8c8d81788583aac7f1957c", null ],
    [ "~Estimator", "classOFELI_1_1Estimator.html#a66fefe296cc283f479648d938ba05052", null ],
    [ "getAverage", "classOFELI_1_1Estimator.html#a1d8ef73d5ae5274e8c004b9b10de2da9", null ],
    [ "getElementWiseIndex", "classOFELI_1_1Estimator.html#a52f5df03e050b74f199dc6e3b6b47c72", null ],
    [ "getMesh", "classOFELI_1_1Estimator.html#a33d260bca42fe66a8536f2eac63adc64", null ],
    [ "getNodeWiseIndex", "classOFELI_1_1Estimator.html#a19bc9a3230f3bd53b2221ad7a74810cf", null ],
    [ "getSideWiseIndex", "classOFELI_1_1Estimator.html#a60ee01b46949013e587259749c20584f", null ],
    [ "setSolution", "classOFELI_1_1Estimator.html#af6fe5bb0ec25b8e2fec7331f7ea33afb", null ],
    [ "setType", "classOFELI_1_1Estimator.html#a97ceb23cb630a1d1e445d786bc04edf9", null ]
];