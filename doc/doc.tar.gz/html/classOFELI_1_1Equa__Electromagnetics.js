var classOFELI_1_1Equa__Electromagnetics =
[
    [ "ElectricConductivity", "classOFELI_1_1Equa__Electromagnetics.html#a5fd5e74e2b08cbd9f0a4d21582b18e48", null ],
    [ "ElectricConductivity", "classOFELI_1_1Equa__Electromagnetics.html#a8f0508214458c79b1da012058364ad40", null ],
    [ "MagneticPermeability", "classOFELI_1_1Equa__Electromagnetics.html#aaaae39e158d68b6422749643570ce498", null ],
    [ "MagneticPermeability", "classOFELI_1_1Equa__Electromagnetics.html#a46e1f0f3840c0013e60118f4562895d2", null ],
    [ "setMaterial", "classOFELI_1_1Equa__Electromagnetics.html#a381ccce0928fbad840a57b054e7eb9b0", null ]
];