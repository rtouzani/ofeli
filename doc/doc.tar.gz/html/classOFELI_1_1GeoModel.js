var classOFELI_1_1GeoModel =
[
    [ "GeoModel", "group__OFELI.html#gae36cda6ebd5f80dc9f69ee63dc85d47a", null ],
    [ "GeoModel", "group__OFELI.html#ga9c49227455bdcadc4550ebbcb2b0f596", null ],
    [ "GeoModel", "group__OFELI.html#ga77fa3e35d33d1bb270ed490c61aa15a8", null ],
    [ "~GeoModel", "group__OFELI.html#ga394e8243329f5ce186c6209e6930c293", null ],
    [ "Bezier", "group__OFELI.html#ga49e9f5cfb40f32148dcb5beb187bfcf3", null ],
    [ "BezierSurface", "group__OFELI.html#ga417ee6ae3a4e5a6748df5c796a562f5c", null ],
    [ "BSpline", "group__OFELI.html#ga0c8eb9746a6bd03bc77f81d4e211d2c4", null ],
    [ "BSplineSurface", "group__OFELI.html#ga1a483b982f0098d857419d459bc114f8", null ],
    [ "Nurbs", "group__OFELI.html#gaa442b2b3efe857fc517d2d8e8ba51e70", null ],
    [ "setBezierPar", "group__OFELI.html#ga6ce02f2598c20931edbbec2fb32ced4e", null ],
    [ "setBezierSurfacePar", "group__OFELI.html#ga5b8d0ce210dc001c30a7834a4b1676c8", null ],
    [ "setBSplinePar", "group__OFELI.html#gaabac2a91c9ac7dd2cc28e34e42783155", null ],
    [ "setBSplineSurfacePar", "group__OFELI.html#ga9ecdfbdf68055c09f184fe5f26b9fa70", null ],
    [ "setData", "group__OFELI.html#ga25ba8c34d74f215eb5fa62036ef83c1e", null ],
    [ "setData", "group__OFELI.html#ga7b51c783ad91edcff67bdf394782d4b4", null ],
    [ "setNurbsPar", "group__OFELI.html#ga905d3581717ef2ef807c744191bca620", null ]
];